
import SwiftUI
import FirebaseFirestore
import Firebase

func addDataToDataBase(userName: String, ibanCard: String, carOwner: String, carBrand: String, carModel: String, carManufact: String, carPrice: String ,statusPin: String) {
    let db = Firestore.firestore()
    
    db.collection("cars").addDocument(data: [
        "userName": userName,
        "ibanCard": ibanCard,
        "carOwner": carOwner,
        "carBrand": carBrand,
        "carModel": carModel,
        "carPrice": carPrice,
        "carManufact": carManufact,
        
        "statusPin": statusPin
    ]) { err in
        if let err = err {
            print("Error adding document: \(err)")
        } else {
            print("Document added successfully")
        }
    }
}


struct FormPage: View {
    
    @State var userName = ""
    @State var ibanCard = ""
    @State var carOwner = ""
    @State var carBrand = ""
    @State var carModel = ""
    @State var carManufact = 2023
    @State var carPrice = ""
    
    @State var statusPin = ""
    @State var carManufactSheet = false
    
    var body: some View {
        
        ScrollView {
            VStack(spacing: 20) {
                
                VStack(alignment: .leading, spacing: 15){
                    
                    Text("Car Owner")
                    TextField("Enter your name", text: $carOwner)
                        .padding()
                        .frame(maxWidth: 360, maxHeight: 60)
                        .overlay(RoundedRectangle(
                            cornerRadius: 10.0).strokeBorder(Color.gray, style: StrokeStyle(lineWidth: 1.0)))
                    
                    Text("Car Brand")
                    TextField("Enter your car brand", text: $carBrand)
                        .padding()
                        .frame(maxWidth: 360, maxHeight: 60)
                        .overlay(RoundedRectangle(
                            cornerRadius: 10.0).strokeBorder(Color.gray, style: StrokeStyle(lineWidth: 1.0)))
                    
                    Text("Car Model")
                    TextField("Enter your car Model", text: $carModel)
                        .padding()
                        .frame(maxWidth: 360, maxHeight: 60)
                        .overlay(RoundedRectangle(
                            cornerRadius: 10.0).strokeBorder(Color.gray, style: StrokeStyle(lineWidth: 1.0)))
                    
                    VStack(alignment: .leading){
                        
                        Text("Car Manufactures")
                        
                        Group{
                            Button(action: {
                                carManufactSheet.toggle()
                            }) {
                                HStack{
                                    Text("\(carManufact)")
                                    CustomNavBarView()
                                }
                                .padding()
                                .overlay(RoundedRectangle(
                                    cornerRadius: 10.0).strokeBorder(Color.gray, style: StrokeStyle(lineWidth: 1.0)))
                                .frame(maxWidth: 360, maxHeight: 60)
                                .foregroundColor(Color("BG"))
                            }
                        }
                    }
                    .foregroundColor(Color("BG"))
                    
                    Text("Car Price")
                    TextField("Enter price", text: $carPrice)
                        .padding()
                        .frame(maxWidth: 360, maxHeight: 60)
                        .overlay(RoundedRectangle(
                            cornerRadius: 10.0).strokeBorder(Color.gray, style: StrokeStyle(lineWidth: 1.0)))
                    
                    
                    AddPhotoSheet()
                    
                }
                .padding()
                .foregroundColor(Color("BG"))
//                .padding(.top, 40)
                
                Spacer()
                
                Button(action: {
                    addDataToDatabase()
                    clearFields()
                }) {
                    Text("Save")
                        .font(.title2)
                        .padding(16)
                        .frame(maxWidth: .infinity)
                        .background(Color("BG"))
                        .cornerRadius(15)
                        .foregroundColor(.white)
                }
            }.padding()
            //        .padding(.top)
                .sheet(isPresented: $carManufactSheet, content: {
                    VStack{
                        Picker("", selection: $carManufact) {
                            ForEach(2000...2023, id: \.self) {
                                Text("\($0)")
                            }
                            .presentationDetents([.height(200), .medium])
                        }.pickerStyle(.wheel)
                    }
                })
        }
    }
    
    func addDataToDatabase() {
        let db = Firestore.firestore()
        
        db.collection("cars").addDocument(data: [
            //            "userName": userName,
            //            "ibanCard": ibanCard,
            "carOwner": carOwner,
            "carBrand": carBrand,
            "carModel": carModel,
            "carPrice": carPrice,
            "carManufact": carManufact,
            
            "statusPin": statusPin
        ]) { err in
            if let err = err {
                print("Error adding document: \(err)")
            } else {
                print("Document added successfully")
            }
        }
    }
    
    func clearFields() {
        userName = ""
        ibanCard = ""
        carOwner = ""
        carBrand = ""
        carModel = ""
        carManufact = 0
        carPrice = ""
        statusPin = ""
    }
}


struct FormPage_Previews: PreviewProvider {
    static var previews: some View {
        FormPage()
    }
}
