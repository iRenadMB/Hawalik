
import SwiftUI

// MARK: Plant Model And Sample Data
struct Car: Identifiable, Equatable {
    var id: String = UUID().uuidString
    var imageName: String
    var carOwner: String
    var carBrand: String
    var carModel: String
    var carManufacture: String

}

var cars: [Car] = [
    
    Car(imageName: "Mazda", carOwner: "Khaled Ali", carBrand: "Mazda", carModel: "C6", carManufacture: "2022"),
    
]

//var isCheckedLike: [Plant] {
//    return plants.filter({ press in
//        return press.isChecked
//    })
//}
