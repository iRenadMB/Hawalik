
import Foundation
import SwiftUI

// MARK: Tab's

enum Tab: String,CaseIterable{

    case home = "Home"
    case scan = "Scan"
    case folder = "Files"
    case cart = "Cart"
}
